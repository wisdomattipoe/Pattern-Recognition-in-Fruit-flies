# -*- coding: utf-8 -*-
"""
Created on Tue Sep  5 08:58:44 2023

@author: easantea and attipowk
"""


import pandas as pd   # Package to enable data import
import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as st
from scipy.stats import sem
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, roc_auc_score
from sklearn.model_selection import train_test_split, cross_val_score, RepeatedStratifiedKFold
from sklearn.preprocessing import StandardScaler


# Load and organize data from windows
#df = pd.read_excel(r'E:\My Documents\Research\Clarkson Research\Research with Ginger\Tissue Patterning Project\Audrey\PythonCode\clustering_features.xlsx')
#df = pd.read_excel(r'C:\Users\attipowk\Desktop\project_python\pattern_feature\auc_accuracy\clustering_features.xlsx')
#df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\auc_accuracy_dbscan\clustering_features_balanced_dbscan_SS.xlsx')

df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\auc_accuracy_dbscan\AUC_files_control_Mutants\Silhouette_score\white_scar.xlsx')



#df = pd.read_excel(r'E:\My Documents\Research\Clarkson Research\Research with Ginger\Tissue Patterning Audrey 2022\Audrey\PythonCode\clustering_features_balanced.xlsx')

# Extract required columns for processing
data = pd.DataFrame(df,columns=['TissueInt','RSA','SS'])


# Convert Dataframe to Numpy array
numpydata = data.to_numpy()

# Standardize input array
scaler = StandardScaler()
xdata_std = scaler.fit_transform(numpydata[:,1:3])

ydata = numpydata[:,0]

# list to store scores
score_list = []


# Number of splits and repeats
mysplits = 4   # K fold cross validation
myrepeats = 10


# Analysis for RSA

xdata =xdata_std[:,0:1]    

# Prepare cross-validation procedure
cv1 = RepeatedStratifiedKFold(n_splits = mysplits, n_repeats=myrepeats,random_state=1)
  
# Create Model
model = LogisticRegression(solver='liblinear',C=0.5, random_state=0)
  
# Evaluate Model
scores = cross_val_score(model,xdata,ydata,scoring='roc_auc',cv=cv1, n_jobs=-1)

# Find median score and interquartile range
auc1_meadian = np.median(scores)
auc1_mean = np.mean(scores)
auc1_iqr = np.quantile(scores,[0.25,0.75])
auc1_ci =st.t.interval(confidence=0.95, df=len(scores)-1, loc=auc1_mean, scale=sem(scores)) 

# Update List
score_list.append(scores)



# Analysis for SS Feature

xdata = xdata_std[:,1:2] 

# Prepare cross-validation procedure
cv1 = RepeatedStratifiedKFold(n_splits = mysplits, n_repeats=myrepeats,random_state=1)
  
# Create Model
model = LogisticRegression(solver='liblinear',C=0.5, random_state=0)
  
# Evaluate Model
scores = cross_val_score(model,xdata,ydata,scoring='roc_auc',cv=cv1, n_jobs=-1)

# Find median score
auc2_meadian = np.median(scores)
auc2_mean = np.mean(scores)
auc2_iqr = np.quantile(scores,[0.25,0.75])
auc2_ci =st.t.interval(confidence=0.95, df=len(scores)-1, loc=auc2_mean, scale=sem(scores))

# Update List
score_list.append(scores)



# Analysis for RSA + SS

xdata = xdata_std[:,0:2]

# Prepare cross-validation procedure
cv1 = RepeatedStratifiedKFold(n_splits = mysplits, n_repeats=myrepeats,random_state=1)
  
# Create Model
model = LogisticRegression(solver='liblinear',C=0.5, random_state=0)
  
# Evaluate Model
scores = cross_val_score(model,xdata,ydata,scoring='roc_auc',cv=cv1, n_jobs=-1)

# Find median score
auc3_meadian = np.median(scores)
auc3_mean = np.mean(scores)
auc3_iqr = np.quantile(scores,[0.25,0.75])
auc3_ci =st.t.interval(confidence=0.95, df=len(scores)-1, loc=auc3_mean, scale=sem(scores))

# Update List
score_list.append(scores)



# Create a box plot of results
fig = plt.figure()
ax = fig.add_subplot(111)
pb = ax.boxplot(score_list,vert=0)

ax.set_yticklabels(['RSA', 'SS',
                    'RSA+SS'])
ax.set_xlabel("AUC of Models")

plt.title(" ")
 
# show plot
plt.show()

###################### plot ROC curves for specific models#############

# Split data into testing and training sets
x_train, x_test, y_train, y_test = train_test_split(xdata_std, ydata, test_size=0.4, random_state=0)


# Train data using logistic regression
model = LogisticRegression(solver='liblinear',C=0.5, random_state=0)

# RSA
model.fit(x_train[:,0:1],y_train)

# Generate ROC curve
y_pred_proba = model.predict_proba(x_test[:,0:1])[:,1]
fpr,tpr,thresholds = roc_curve(y_test,y_pred_proba)
auc = roc_auc_score(y_test,y_pred_proba)
#ythreshrsa = thresholds[np.argmax(tpr-fpr)]

#Create ROC curve
fig = plt.figure()
plt.plot(fpr,tpr, label="AUC="+str(round(auc,2)))
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.legend(loc = 4)
plt.show()



# Evaluate the Logistic regression model

y_predict = model.predict(x_test[:,0:1])
#y_predict_class = [1 if prob > ythreshrsa else 0 for prob in y_pred_proba]
#cmat = confusion_matrix(y_test,y_predict_class)
cmat = confusion_matrix(y_test,y_predict)

print(cmat)

# Classification Report
print (classification_report(y_test,y_predict))



# SS
model.fit(x_train[:,1:2],y_train)


# Generate ROC curve
y_pred_proba = model.predict_proba(x_test[:,1:2])[:,1]
fpr,tpr,thresholds = roc_curve(y_test,y_pred_proba)
auc = roc_auc_score(y_test,y_pred_proba)
ythreshcq = thresholds[np.argmax(tpr-fpr)]

#Create ROC curve
plt.plot(fpr,tpr, label="AUC="+str(round(auc,2)))
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.legend(loc = 4)
plt.show()


# Evaluate the Logistic regression model

y_predict = model.predict(x_test[:,1:2])
#y_predict_class = [1 if prob > ythreshcq else 0 for prob in y_pred_proba]
#cmat = confusion_matrix(y_test,y_predict_class)
cmat = confusion_matrix(y_test,y_predict)

print(cmat)

# Classification Report
print (classification_report(y_test,y_predict))

#print (classification_report(y_test,y_predict_class))




# RSA + SS
model.fit(x_train[:,0:2],y_train)

# Generate ROC curve
y_pred_proba = model.predict_proba(x_test[:,0:2])[:,1]
fpr,tpr,_ = roc_curve(y_test,y_pred_proba)
auc = roc_auc_score(y_test,y_pred_proba)
ythreshcqrsa = thresholds[np.argmax(tpr-fpr)]

#Create ROC curve
plt.plot(fpr,tpr, label="AUC="+str(round(auc,2)))
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.legend(loc = 4)
plt.show()

# Evaluate the logistic regression model
y_predict = model.predict(x_test[:,0:2])
#y_predict_class = [1 if prob > ythreshcqrsa else 0 for prob in y_pred_proba]
#cmat = confusion_matrix(y_test,y_predict_class)
cmat = confusion_matrix(y_test,y_predict)

print(cmat)

# Classification Report
print (classification_report(y_test,y_predict))

#print (classification_report(y_test,y_predict_class))


