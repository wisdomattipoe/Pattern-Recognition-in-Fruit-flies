These python codes do a variety of things listed below.

likelihood_ratio_test_dbscan: Performs a likelihood ratio test for RSA and the dbscan features()

auc_accuracy_dbscan: Performs a cross validation, Area under the ROC curve, classification reports,
logistic regression, training of data set, receiver operating characteristic curve, etc.
Plots are generated for the AUC and ROC aswell

pattern_dbscan_features: Performs a kruskal wallis H-test and Manwhitnney U-test for all the collected features and returns their results. 
You will have to reorganise your spreadsheet (features) in the required format
It generates a box plot(image) for the features as well. 