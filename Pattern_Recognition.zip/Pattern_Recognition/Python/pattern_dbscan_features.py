# -*- coding: utf-8 -*-
"""
Created on Sat Jun 29 22:13:43 2024

@author: attipowk
"""


import pandas as pd   # Package to enable data import
import matplotlib.pyplot as plt # this is for plotting
import numpy as np              # this is for arithmetic     
import scipy.stats as st
import seaborn as sns
from scipy.stats import sem
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, roc_auc_score
from sklearn.model_selection import train_test_split, cross_val_score, RepeatedStratifiedKFold
from sklearn.preprocessing import StandardScaler

###################### SENSORY AREA ANALYSIS#############################################################################
# Load and organize data from windows
#df = pd.read_excel(r'E:\My Documents\Research\Clarkson Research\Research with Gingprer\Tissue Patterning Project\Audrey\PythonCode\RelativeSensoryData.xlsx')
df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\Relative_Sensory_Area.xlsx')



# Extract required columns for processing
data= pd.DataFrame(df)

# Perform Kruskal-Wallis Test
H, resultsSA = st.kruskal(data['Control DCR2'],data['Control White'],data['Mindbomb'], data['Crinkled'], data['Myosin VIIb'],data['Myosin XV'], data['Myosin VI'], data['SCAR'], data['Scabrous'],nan_policy='omit')
# Test to see if there is a difference between all the tissues
#It retuns a probability to validate is there is a difference (threshold = 0.05)


# Perform Mannwhiteney rank sum test on pairwise samples
parraySA = [[0]*8 for i in range(2)]
U,parraySA[0][0] = st.mannwhitneyu(data['Control DCR2'].dropna(),data['Control White'].dropna())     # Dcr2 vs White
U,parraySA[0][1] = st.mannwhitneyu(data['Control DCR2'].dropna(),data['Mindbomb'].dropna())          # Dcr2 vs Mindbomb
U,parraySA[1][0] = st.mannwhitneyu(data['Control White'].dropna(),data['Control DCR2'].dropna())     # White vs DCR2
U,parraySA[1][1] = st.mannwhitneyu(data['Control White'].dropna(),data['Mindbomb'].dropna())         # White vs Mindbomb
U,parraySA[1][2] = st.mannwhitneyu(data['Control White'].dropna(),data['Crinkled'].dropna())         # White vs Crinkled
U,parraySA[1][3] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin VIIb'].dropna())      # White vs Myosin 7b
U,parraySA[1][4] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin XV'].dropna())        # White vs Myosin XV
U,parraySA[1][5] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin VI'].dropna())        # White vs Myosin VI
U,parraySA[1][6] = st.mannwhitneyu(data['Control White'].dropna(),data['SCAR'].dropna())             # White vs SCAR
U,parraySA[1][7] = st.mannwhitneyu(data['Control White'].dropna(),data['Scabrous'].dropna())         # White vs Scabrous


plt.figure(1)
sns.boxplot(data = df,orient="h", linewidth=2.5, saturation=0.9)
plt.title("Relative Sensory Area", fontsize = 16)

###################### CLUSTER NUMBER ANALYSIS #############################################################################
# Load and organize data from windows
#df = pd.read_excel(r'E:\My Documents\Research\Clarkson Research\Research with Ginger\Tissue Patterning Project\Audrey\PythonCode\ClusterNumber.xlsx')
df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\Cluster_Number_dbscan.xlsx')
# Extract required columns for processing
data= pd.DataFrame(df)

# Perform Kruskal-Wallis Test
H, resultsCN = st.kruskal(data['Control DCR2'],data['Control White'],data['Mindbomb'], data['Crinkled'], data['Myosin VIIb'],data['Myosin XV'], data['Myosin VI'], data['SCAR'], data['Scabrous'],nan_policy='omit')

# Perform Mannwhiteney rank sum test on pairwise samples
parrayCN = [[0]*8 for i in range(2)]
U,parrayCN[0][0] = st.mannwhitneyu(data['Control DCR2'].dropna(),data['Control White'].dropna())     # Dcr2 vs White
U,parrayCN[0][1] = st.mannwhitneyu(data['Control DCR2'].dropna(),data['Mindbomb'].dropna())          # Dcr2 vs Mindbomb
U,parrayCN[1][0] = st.mannwhitneyu(data['Control White'].dropna(),data['Control DCR2'].dropna())     # White vs DCR2...this is a check to see if things are rioght
U,parrayCN[1][1] = st.mannwhitneyu(data['Control White'].dropna(),data['Mindbomb'].dropna())         # White vs Mindbomb
U,parrayCN[1][2] = st.mannwhitneyu(data['Control White'].dropna(),data['Crinkled'].dropna())         # White vs Crinkled
U,parrayCN[1][3] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin VIIb'].dropna())      # White vs Myosin 7b
U,parrayCN[1][4] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin XV'].dropna())        # White vs Myosin XV
U,parrayCN[1][5] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin VI'].dropna())        # White vs Myosin VI
U,parrayCN[1][6] = st.mannwhitneyu(data['Control White'].dropna(),data['SCAR'].dropna())             # White vs SCAR
U,parrayCN[1][7] = st.mannwhitneyu(data['Control White'].dropna(),data['Scabrous'].dropna())         # White vs Scabrous

plt.figure(2)
sns.boxplot(data = df,orient="h", linewidth=2.5, saturation=0.9)
plt.title('Cluster Number', fontsize = 16)

###################### CLUSTER SIZE ANALYSIS #############################################################################
# Load and organize data from windows
#df = pd.read_excel(r'E:\My Documents\Research\Clarkson Research\Research with Ginger\Tissue Patterning Project\Audrey\PythonCode\ClusterSizeHomogeneity.xlsx')
df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\Cluster_Size_Variance_dbscan.xlsx')
# Extract required columns for processing
data= pd.DataFrame(df)

# Perform Kruskal-Wallis Test
H, resultsCS = st.kruskal(data['Control DCR2'],data['Control White'],data['Mindbomb'], data['Crinkled'], data['Myosin VIIb'],data['Myosin XV'], data['Myosin VI'], data['SCAR'], data['Scabrous'],nan_policy='omit')

# Perform Mannwhiteney rank sum test on pairwise samples
parrayCS = [[0]*8 for i in range(2)]
U,parrayCS[0][0] = st.mannwhitneyu(data['Control DCR2'].dropna(),data['Control White'].dropna())     # Dcr2 vs White
U,parrayCS[0][1] = st.mannwhitneyu(data['Control DCR2'].dropna(),data['Mindbomb'].dropna())          # Dcr2 vs Mindbomb
U,parrayCS[1][0] = st.mannwhitneyu(data['Control White'].dropna(),data['Control DCR2'].dropna())     # White vs DCR2
U,parrayCS[1][1] = st.mannwhitneyu(data['Control White'].dropna(),data['Mindbomb'].dropna())         # White vs Mindbomb
U,parrayCS[1][2] = st.mannwhitneyu(data['Control White'].dropna(),data['Crinkled'].dropna())         # White vs Crinkled
U,parrayCS[1][3] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin VIIb'].dropna())      # White vs Myosin 7b
U,parrayCS[1][4] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin XV'].dropna())        # White vs Myosin XV
U,parrayCS[1][5] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin VI'].dropna())        # White vs Myosin VI
U,parrayCS[1][6] = st.mannwhitneyu(data['Control White'].dropna(),data['SCAR'].dropna())             # White vs SCAR
U,parrayCS[1][7] = st.mannwhitneyu(data['Control White'].dropna(),data['Scabrous'].dropna())         # White vs Scabrous


plt.figure(3)
sns.boxplot(data = df,orient="h", linewidth=2.5, saturation=0.9)
plt.title('Cluster Size Variance', fontsize = 16)

###################### SILHOUETTE SCORE ANALYSIS #############################################################################
# Load and organize data from windows
#df = pd.read_excel(r'E:\My Documents\Research\Clarkson Research\Research with Ginger\Tissue Patterning Project\Audrey\PythonCode\ClusterQuality.xlsx')
df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\Silhouette_score_dbscan.xlsx')
# Extract required columns for processing
data= pd.DataFrame(df)

# Perform Kruskal-Wallis Test
H, resultsCQ = st.kruskal(data['Control DCR2'],data['Control White'],data['Mindbomb'], data['Crinkled'], data['Myosin VIIb'],data['Myosin XV'], data['Myosin VI'], data['SCAR'], data['Scabrous'],nan_policy='omit')

# Perform Mannwhiteney rank sum test on pairwise samples
parrayCQ = [[0]*8 for i in range(2)]
U,parrayCQ[0][0] = st.mannwhitneyu(data['Control DCR2'].dropna(),data['Control White'].dropna())     # Dcr2 vs White
U,parrayCQ[0][1] = st.mannwhitneyu(data['Control DCR2'].dropna(),data['Mindbomb'].dropna())          # Dcr2 vs Mindbomb
U,parrayCQ[1][0] = st.mannwhitneyu(data['Control White'].dropna(),data['Control DCR2'].dropna())     # White vs DCR2
U,parrayCQ[1][1] = st.mannwhitneyu(data['Control White'].dropna(),data['Mindbomb'].dropna())         # White vs Mindbomb
U,parrayCQ[1][2] = st.mannwhitneyu(data['Control White'].dropna(),data['Crinkled'].dropna())         # White vs Crinkled
U,parrayCQ[1][3] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin VIIb'].dropna())      # White vs Myosin 7b
U,parrayCQ[1][4] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin XV'].dropna())        # White vs Myosin XV
U,parrayCQ[1][5] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin VI'].dropna())        # White vs Myosin VI
U,parrayCQ[1][6] = st.mannwhitneyu(data['Control White'].dropna(),data['SCAR'].dropna())             # White vs SCAR
U,parrayCQ[1][7] = st.mannwhitneyu(data['Control White'].dropna(),data['Scabrous'].dropna())         # White vs Scabrous


plt.figure(4)
sns.boxplot(data = df,orient="h", linewidth=2.5, saturation=0.9)
plt.title('Silhouette Score', fontsize = 16)


#### Outlier Proportion Analysis ####
df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\outlier_proportion_dbscan.xlsx')
# Extract required columns for processing
data= pd.DataFrame(df)

# Perform Kruskal-Wallis Test
H, resultsOP = st.kruskal(data['Control DCR2'],data['Control White'],data['Mindbomb'], data['Crinkled'], data['Myosin VIIb'],data['Myosin XV'], data['Myosin VI'], data['SCAR'], data['Scabrous'],nan_policy='omit')

# Perform Mannwhiteney rank sum test on pairwise samples
parrayOP = [[0]*8 for i in range(2)]
U,parrayOP[0][0] = st.mannwhitneyu(data['Control DCR2'].dropna(),data['Control White'].dropna())     # Dcr2 vs White
U,parrayOP[0][1] = st.mannwhitneyu(data['Control DCR2'].dropna(),data['Mindbomb'].dropna())          # Dcr2 vs Mindbomb
U,parrayOP[1][0] = st.mannwhitneyu(data['Control White'].dropna(),data['Control DCR2'].dropna())     # White vs DCR2
U,parrayOP[1][1] = st.mannwhitneyu(data['Control White'].dropna(),data['Mindbomb'].dropna())         # White vs Mindbomb
U,parrayOP[1][2] = st.mannwhitneyu(data['Control White'].dropna(),data['Crinkled'].dropna())         # White vs Crinkled
U,parrayOP[1][3] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin VIIb'].dropna())      # White vs Myosin 7b
U,parrayOP[1][4] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin XV'].dropna())        # White vs Myosin XV
U,parrayOP[1][5] = st.mannwhitneyu(data['Control White'].dropna(),data['Myosin VI'].dropna())        # White vs Myosin VI
U,parrayOP[1][6] = st.mannwhitneyu(data['Control White'].dropna(),data['SCAR'].dropna())             # White vs SCAR
U,parrayOP[1][7] = st.mannwhitneyu(data['Control White'].dropna(),data['Scabrous'].dropna())         # White vs Scabrous

plt.figure(5)
sns.boxplot(data = df,orient="h", linewidth=2.5, saturation = 0.9)
plt.title('Outlier_Proportion', fontsize = 16)

#Manwhiteney results
#print(parraySA)
#print(parrayCQ)
#print(parrayCS)
print(parrayOP)

#kruskal wallis results of probability
print(resultsSA)
print(resultsCQ) # Cluster quality is now Solihouette score
print(resultsCS)
print(resultsCN)
print(resultsOP)

#print(parrayCS)
#print(parrayCQ)
#plt.show()
plt.show(block=False)

temp = 1                     
                                