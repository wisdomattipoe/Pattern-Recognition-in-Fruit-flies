# -*- coding: utf-8 -*-
"""
Created on Sun Feb 25 23:34:07 2024

@author: attipowk
"""


import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy import stats
import pandas as pd   # Package to enable data import
import matplotlib.pyplot as plt
import numpy as np
import scipy.stats as st
from scipy.stats import sem
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, roc_auc_score
from sklearn.model_selection import train_test_split, cross_val_score, RepeatedStratifiedKFold
from sklearn.preprocessing import StandardScaler
stats.chisqprob = lambda chisq, df: stats.chi2.sf(chisq, df)

# Define function to perform likelihood ratio test

def lrtest(llmin, llmax):
    lr = 2 * (llmax - llmin)
    p = stats.chisqprob(lr, 1) # llmax has 1 dof more than llmin
    return lr, p

# import all data

#df = pd.read_excel(r'E:\My Documents\Research\Clarkson Research\Research with Ginger\Tissue Patterning Project\Audrey\PythonCode\clustering_features_mindbomb.xlsx')
#df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\Regression_Analysis_dbscan\Crinkled_White_dbscan.xlsx')
#df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\Regression_Analysis_dbscan\Mindbomb_Dcr2_dbscan.xlsx')
#df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\Regression_Analysis_dbscan\MyosinVI_White_dbscan.xlsx')
#df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\Regression_Analysis_dbscan\MyosinVIIb_White_dbscan.xlsx')


df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\Regression_Analysis_dbscan\MyosinXV_White_dbscan.xlsx')
#df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\Regression_Analysis_dbscan\Scabrous_White_dbscan.xlsx')
#df = pd.read_excel(r'C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Python_file\Regression_Analysis_dbscan\Scar_White_dbscan.xlsx')



# Extract required columns for processing
data = pd.DataFrame(df,columns=['TissueInt','RSA','CSV','Sil_score', 'outlier_prop'])

# Convert Dataframe to Numpy array
numpydata = data.to_numpy()

# Standardize input array
scaler = StandardScaler()
#xdata_std = numpydata[:,1:4]

# Separate data for mutants
#type_data = numpydata[:,1]

xdata_std = scaler.fit_transform(numpydata[:,1:5])

ydata = numpydata[:,0]

# Fit logistic regression model with RSA
xdata = xdata_std[:,0:1]
xdata = sm.add_constant(xdata)
model = sm.Logit(ydata,xdata)
mdf = model.fit(method='newton')
print('logistic regression with RSA')
print(mdf.summary())
llfrsa = mdf.llf

# Fit logistic regression model with CSV
xdata = xdata_std[:,1:2]
xdata = sm.add_constant(xdata)
model = sm.Logit(ydata,xdata)
mdf = model.fit(method='newton')
print('logistic regression with CSV')
print(mdf.summary())

# Fit logistic regression model with Silhouette score 
xdata = xdata_std[:,2:3]
xdata = sm.add_constant(xdata)
model = sm.Logit(ydata,xdata)
mdf = model.fit(method='newton')
print('logistic regression with Sil_score')
print(mdf.summary())


# Fit logistic regression model with RSA + CSV
xdata = xdata_std[:,[0,1]]
xdata = sm.add_constant(xdata)
model = sm.Logit(ydata,xdata)
mdf = model.fit(method='newton')
print('logistic regression with RSA+CSV')
print(mdf.summary())
llfcsv = mdf.llf

# Fit logistic regression model with RSA + SS
xdata = xdata_std[:,[0,2]]
xdata = sm.add_constant(xdata)
model = sm.Logit(ydata,xdata)
mdf = model.fit(method='newton')
print('logistic regression with RSA+SS')
print(mdf.summary())
llfcq = mdf.llf

#Fit logistic regression model with RSA + OP
xdata = xdata_std[:,[0,3]]
xdata = sm.add_constant(xdata)
model = sm.Logit(ydata,xdata)
mdf = model.fit(method='newton')
print('logistic regression with RSA+OP')
print(mdf.summary())
llfop = mdf.llf


#Fit logistic regression model with RSA + CSV + CSS
xdata = xdata_std[:,[0,1,2]]
xdata = sm.add_constant(xdata)
model = sm.Logit(ydata,xdata)
mdf = model.fit(method='newton')
print(mdf.summary())
llfcsvcq = mdf.llf


# # fit time only to pig weight
# md = smf.mixedlm("Weight ~ Time", data, groups=data["Pig"])
# mdf = md.fit(reml=False)
# print(mdf.summary())
# llf = mdf.llf

# # fit time and litter to pig weight
# mdlitter = smf.mixedlm("Weight ~ Time + Litter", data, groups=data["Pig"])
# mdflitter = mdlitter.fit(reml=False)
# print(mdflitter.summary())
# llflitter = mdflitter.llf

# Results of likelihood ratio test


lr, p = lrtest(llfrsa, llfcsv)
print('RSA vs RSA + CSV')
print('LR test, p value: {:.2f}, {:.4f}'.format(lr, p))

lr, p = lrtest(llfrsa, llfcq)
print('RSA vs RSA + SS')
print('LR test, p value: {:.2f}, {:.4f}'.format(lr, p))

lr, p = lrtest(llfrsa, llfop)
print('RSA vs RSA + OP')
print('LR test, p value: {:.2f}, {:.4f}'.format(lr, p))


lr, p = lrtest(llfcsv, llfcsvcq)
print('RSA + CSV vs RSA + CSV+CQ')
print('LR test, p value: {:.2f}, {:.4f}'.format(lr, p))