The Matlab file has multiple functions that 
1. organises the data for processing
2. Performs clustering on the data set using DBscan algorithm 

The Python file mostly does 
1. Regression analysis 
2. CLassification
3. ROC and AUC analysis
4. Logistic regression  