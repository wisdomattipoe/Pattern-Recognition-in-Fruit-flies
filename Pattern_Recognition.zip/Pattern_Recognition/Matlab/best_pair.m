function[silh, epss, minpts] = best_pair(data)
% This is a function that takes in a data set (data) and returns the
% optimal silhouette score, epsilon and minimum point. 
    
    data1 = [data(:,1) data(:,2)]; %Data1 extraxts the first and second column of data 
    eps = linspace(25,35,81); %possible eps values from 25 to 35 with 81 possibilities 
    min_pts = linspace(2,6,5); %possible min_pt values from 2 to 6

    % eps = linspace(0.5,1.5,11); %possible eps values 
    % min_pts = linspace(2,5,4); %possible min_pt values

    scores = []; %empty list to store reults 
    for i=1:length(eps)
        for j=1:length(min_pts)
            idx1 = dbscan(data1, eps(i), min_pts(j));
            %run the dbscan on each pair of pint from eps and min_pnt
            %The idx1 is a vector of the clusters 
        
            if length(unique(idx1))>1 % Do this when there is clustering 
                ss1 = silhouette(data1, idx1);% silhouette score for each point
                sco1 = mean(ss1); %silhoutte score for the data set
                scores = [scores;sco1]; %Store the silhouette score in score list 
            else
                sco1 = -1; %the cluster is purely an outlier 
                scores = [scores;sco1];
            end
        end
    end 
    silh = max(scores); % this gives the best silhouette score for data1
    
    %This for loop gives the best eps and min_pnt
    for i=1:length(eps)
        for j=1:length(min_pts)
            if silh == mean(silhouette(data1, dbscan(data1, eps(i), min_pts(j))))
                epss = eps(i);
                minpts = min_pts(j);
            end
        end
    end    
end

