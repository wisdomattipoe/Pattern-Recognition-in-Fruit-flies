patern_main_extract_data: This is a code that takes in multiple sets of spreadsheets for different mutants of fruitflies and 
organises it into a single but large matrix file called "tissueData". You will have to specifiy the exact file path to your data 
for this to work right. The code returns "tissueData" as its output. 


DBSCAN_1: The contents of tissueData is later extracted and the DBscan algorithm used to perform clustering for each data set of each mutant. 
The features "cluster number, cluster size variance, silhouette score, outlier prevalence" are extracted from each spreadsheet. 
The results are stored as a spreadsheet. 

best_pair: input - spreadsheet
           output - best epsilon radius required to perform the DBscan
 

