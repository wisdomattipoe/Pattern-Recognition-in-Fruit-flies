% Code to extract bristol cells clustering features from Heminota Data
% by Wisdom K. Attipoe
% 12/07/2023

clc
close all

%%% Append all excel data into respective file %%%

%%%Folder Paths %%%%%    Fix the paths 
DCR2folderpath = "C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Control1DCR2";
Whitefolderpath = "C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Control2White\";
Mindfolderpath = "C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Mindbomb1\";
Crinkledfolderpath = "C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Myosin VIIaCrinkled\";
Myosin15folderpath = "C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Myosin XV\";
Myosin6folderpath = "C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\MyosinVI";
Myosin7bfolderpath = "C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\MyosinVIIb";
Scabrousfolderpath = "C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\Scabrous\";
SCARfolderpath = "C:\Users\attipowk\Documents\MATLAB\Patterning_DBSCAN\SCAR\";

%Create an empty array to store final data 
datalist = {}; 

folder_list = [DCR2folderpath, Whitefolderpath, Mindfolderpath, Crinkledfolderpath, Myosin15folderpath, Myosin6folderpath, Myosin7bfolderpath, Scabrousfolderpath, SCARfolderpath];
for j =1:length(folder_list)
    temp = {};
    folderpath = folder_list(j); 
    files = dir(fullfile(folderpath, '*.xlsx')); % Loop through each Excel file and append to respective folder
    for i = 1:length(files)
        temp{end+1} = files(i).name;
    end
    datalist{end + 1} = temp;
end

%Assign the things in datalist to their respective names 
Dcr2 = datalist{1};
White = datalist{2};
Mindbomb = datalist{3};
Crinkled = datalist{4};
Myosin15 = datalist{5};
Myosin6 = datalist{6};
Myosin7b = datalist{7};
Scabrous = datalist{8};
SCAR =datalist{9};

%% Import data for all tissue types
lenDcr2 = length(Dcr2);  % 0 is DCR2
lenWhite = length(White);  % 1 is white 
lenMindbomb = length(Mindbomb);
lenCrinkled = length(Crinkled);
lenMyosin7b = length(Myosin7b);
lenMyosin6 = length(Myosin6);
lenMyosin15 = length(Myosin15);
lenSCAR = length(SCAR);
lenscabrous = length(Scabrous);

% Create cell array to store clustering features
celldata = cell(lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b+lenMyosin15+...
    lenMyosin6+lenSCAR+lenscabrous,7);
%celldata{a, b} a is row and b is column. Cell data stores larger things
%not just numbers 

%%%%Add-Path%%%

%Import data for Dcr2
addpath("C:\Users\attipowk\Documents\MATLAB\Data_Folder\Spreadsheets\Control1DCR2\");
for i = 1:lenDcr2
    celldata{i,1} = 0;
    celldata{i,2} = readmatrix(Dcr2{i});
end

% Import data for White
addpath("C:\Users\attipowk\Documents\MATLAB\Data_Folder\Spreadsheets\Control2White\");
for i = 1:lenWhite
    celldata{i+lenDcr2,1} = 1;
    celldata{i+lenDcr2,2} = readmatrix(White{i});
end

% Import data for Mindbomb
addpath("C:\Users\attipowk\Documents\MATLAB\Data_Folder\Spreadsheets\Mindbomb1\");
for i = 1:lenMindbomb
    celldata{i+lenDcr2+lenWhite,1} = 2;
    celldata{i+lenDcr2+lenWhite,2} =readmatrix(Mindbomb{i});
end

% Import data for Crinkled
addpath("C:\Users\attipowk\Documents\MATLAB\Data_Folder\Spreadsheets\Myosin VIIaCrinkled\");
for i = 1:lenCrinkled
    celldata{i+lenDcr2+lenWhite+lenMindbomb,1} = 3;
    celldata{i+lenDcr2+lenWhite+lenMindbomb,2} =readmatrix(Crinkled{i});
end

% Import data for Myosin7b
addpath("C:\Users\attipowk\Documents\MATLAB\Data_Folder\Spreadsheets\MyosinVIIb");
for i = 1:lenMyosin7b
    celldata{i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled,1} = 4;
    celldata{i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled,2} =readmatrix(Myosin7b{i});
end
% Import data for Myosin15
addpath("C:\Users\attipowk\Documents\MATLAB\Data_Folder\Spreadsheets\Myosin XV\");
for i = 1:lenMyosin15
    celldata{i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b,1} = 5;
    celldata{i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b,2} = readmatrix(Myosin15{i});
end
% Import data for Myosin6
addpath("C:\Users\attipowk\Documents\MATLAB\Data_Folder\Spreadsheets\MyosinVI");
for i = 1:lenMyosin6
    celldata{i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b+lenMyosin15,1} = 6;
    celldata{i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b+lenMyosin15,2} = readmatrix(Myosin6{i});
end
% Import data for SCAR
addpath("C:\Users\attipowk\Documents\MATLAB\Data_Folder\Spreadsheets\SCAR\");
for i = 1:lenSCAR
    celldata{i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b+lenMyosin15+lenMyosin6,1} = 7;
    celldata{i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b+lenMyosin15+lenMyosin6,2} = readmatrix(SCAR{i});
end
% Import data for scabrous
addpath("C:\Users\attipowk\Documents\MATLAB\Data_Folder\Spreadsheets\Scabrous\");
for i = 1:lenscabrous
    celldata{i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b+lenMyosin15+lenMyosin6+lenSCAR,1} = 8;
    celldata{i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b+lenMyosin15+lenMyosin6+lenSCAR,2} = readmatrix(Scabrous{i});
end


save tissueData celldata