%This code runs the dbscan on all the tissues saved in celldata using
%best_pair

clc
close all 
warning off

% Import data
 load tissueData.mat
 [tissuenum,~] = size(celldata); %tissuenum = number of rows of cell data
 rng('default'); 

  % Create clusters and store information
 for i = 1:tissuenum
     alldata = celldata{i,2}; %this pulls the excel file in celldata
     centers = alldata(:,2:3); %This extracts the X and Y columns 

     %Get the silhoute score, best epsilon and minimum points from the data
     %set using the best pair function
     [silh, epss, minpts] = best_pair(centers);
     
     % Run the dbscan using the best eps and minpts and number of clusters
     eva = dbscan(centers, epss, minpts);
     cluster_number = length(unique(eva));
     

     % Determine cluster centers
     celldata{i,3}=cluster_number; 
     celldata{i,4} = silh;   %Criterion describes the quality of a cluster
     celldata{i,6}=eva;  %idx is a vector representing each cluster 
 end


 %Now we obtain the Cluster size variance (CSV):
 %Generate cluster features for each tissue
for i = 1:tissuenum
    
     % Extract centers
    centers_struct = celldata{i,2};
    centers = centers_struct(:,2:3);
    [datalen,~] = size(centers);
     
     % Calculate centroid of data
     tcentroid = mean(centers,1);
     
     % Extract clusters in tissue
     clusternum = celldata{i,3};
     % clist = celldata{i,5};
     indx = celldata{i,6};
     
     % Create vectors to store features
     cluster_size = zeros(1,clusternum);                                    % Cluster size
     cluster_dist = zeros(1,clusternum);                                    % Cluster distance
     bcluster_variance = zeros(1,clusternum);                               % Between cluster variance
     wcluster_variance = zeros(1,clusternum);                               % Within cluster variance
    
    for j = 1:clusternum
        % ccentroid = clist(j,:);
        cluster_centers = centers(indx==j,:);
        [cluster_size(j),~] = size(cluster_centers);
        % cluster_dist(j) = norm(tcentroid-ccentroid);
        % bcluster_variance(j)= (cluster_size(j)/datalen)*cluster_dist(j)^2;
        % clustervec = cluster_centers-ccentroid;
        % wcluster_variance(j) = sum(diag(clustervec*clustervec'));
    end         

    celldata{i,5}= (1/(clusternum-1))*sum(((cluster_size-mean(cluster_size))/datalen).^2); % Cluster Size Variance                                    % Variance in cluster size
    % bcv = (1/(clusternum-1))*sum(bcluster_variance);                                     % Between cluster variance   
    % wcv = (1/(datalen-clusternum))*sum(wcluster_variance);                               % Within cluster variance   
    % celldata{i,8}= bcv/wcv;   
    % Cluster Quality   
    

    %Cluster feature  Outlier proportion
    indxx = celldata{i,6}; %extract the labelled clusters
    out_count = sum(indxx == -1); %count the number of outliers
    out_prop = out_count./length(indxx);
    celldata{i, 7} = out_prop;
end

figure
%set(0,'defaultaxesfontsize',15); 
%Cluster plot for DCR2
for i = 1:lenDcr2
    centers_struct = celldata{i,2}; %Pull out the excel file
    centers = centers_struct(:,2:3); % pull out X and Y column
    subplot(6,6,i)  % Plot images on a 6 by 6 grid

    [silh, epss, minpts] = best_pair(centers);
    idx11 = dbscan(centers, epss, minpts);
    
    gscatter(centers(:,1), centers(:,2),idx11,'rgbm','.',8); 
    %legend('Location','northeastoutside')
    legend('off')
    hold on
    title(num2str(i))
    hold off
end
sgtitle('Dcr2 Tissues')

figure
for i = 1:lenWhite
    p = i+lenDcr2;
    centers_struct = celldata{p,2};
    centers = centers_struct(:,2:3);

    subplot(10,7,i)
    [silh, epss, minpts] = best_pair(centers);
    idx11 = dbscan(centers, epss, minpts);
    gscatter(centers(:,1), centers(:,2),idx11,'rgbm','.',8); 
    %legend('Location','northeastoutside')
    legend('off')
    hold on
    title(num2str(i))
    hold off
end
sgtitle('White Tissues')


% Visualize clusters for Mindbomb
figure
for i = 1:lenMindbomb
    p = i+lenDcr2+lenWhite;
    centers_struct = celldata{p,2};
    centers = centers_struct(:,2:3);

    subplot(11,4,i)
    [silh, epss, minpts] = best_pair(centers);
    idx11 = dbscan(centers, epss, minpts);
    gscatter(centers(:,1), centers(:,2),idx11,'rgbm','.',8); 
    %legend('Location','northeastoutside')
    legend('off')
    hold on
    title(num2str(i))
    hold off
end
sgtitle('Mindbomb Tissues')

% Visualize clusters for Crinkled
figure
for i = 1:lenCrinkled
    p = i+lenDcr2+lenWhite+lenMindbomb;
    centers_struct = celldata{p,2};
    centers = centers_struct(:,2:3);


    subplot(7,7,i)
    [silh, epss, minpts] = best_pair(centers);
    idx11 = dbscan(centers, epss, minpts);
    gscatter(centers(:,1), centers(:,2),idx11,'rgbm','.',8);
    %legend('Location','northeastoutside')
    legend('off')
    hold on
    title(num2str(i))
    hold off
end
sgtitle('Crinkled Tissues')


% Visualize clusters for Myosin7b
figure
for i = 1:lenMyosin7b
    p = i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled;
    centers_struct = celldata{p,2};
    centers = centers_struct(:,2:3);
    
    subplot(6,5,i)
    [silh, epss, minpts] = best_pair(centers);
    idx11 = dbscan(centers, epss, minpts);
    gscatter(centers(:,1), centers(:,2),idx11,'rgbm','.',8); 
    %legend('Location','northeastoutside')
    legend('off')
    hold on
    title(num2str(i))
    hold off
end
sgtitle('Myosin7b Tissues')


% Visualize clusters for Myosin15
figure
for i = 1:lenMyosin15
    p = i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b;
    centers_struct = celldata{p,2};
    centers = centers_struct(:,2:3);

    subplot(8,8,i)
    [silh, epss, minpts] = best_pair(centers);
    idx11 = dbscan(centers, epss, minpts);
    gscatter(centers(:,1), centers(:,2),idx11,'rgbm','.',8);
    %legend('Location','northeastoutside')
    legend('off')
    hold on
    title(num2str(i))
    hold off
end
sgtitle('Myosin15 Tissues')


% Visualize clusters for Myosin6
figure
for i = 1:lenMyosin6
    p = i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b+lenMyosin15;
    centers_struct = celldata{p,2};
    centers = centers_struct(:,2:3);
    
    subplot(4,4,i)
    [silh, epss, minpts] = best_pair(centers);
    idx11 = dbscan(centers, epss, minpts);
    gscatter(centers(:,1), centers(:,2),idx11,'rgbm','.',8); 
    %legend('Location','northeastoutside')
    legend('off')
    hold on
    title(num2str(i))
    hold off
end
sgtitle('Myosin6 Tissues')

% Visualize clusters for SCAR
figure
for i = 1:lenSCAR
    p = i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b+lenMyosin15+lenMyosin6;
    centers_struct = celldata{p,2};
    centers = centers_struct(:,2:3);
    
    subplot(6,6,i)
    [silh, epss, minpts] = best_pair(centers);
    idx11 = dbscan(centers, epss, minpts);
    gscatter(centers(:,1), centers(:,2),idx11,'rgbm','.',8); 
    %legend('Location','northeastoutside')
    legend('off')
    hold on
    title(num2str(i))
    hold off
end
sgtitle('SCAR Tissues')


% Visualize clusters for scabrous
figure
for i = 1:lenscabrous
    p = i+lenDcr2+lenWhite+lenMindbomb+lenCrinkled+lenMyosin7b+lenMyosin15+lenMyosin6+lenSCAR;
    centers_struct = celldata{p,2};
    centers = centers_struct(:,2:3);
    
    subplot(7,7,i)
    [silh, epss, minpts] = best_pair(centers);
    idx11 = dbscan(centers, epss, minpts);
    gscatter(centers(:,1), centers(:,2),idx11,'rgbm','.',8); 
    %legend('Location','northeastoutside')
    legend('off')
    hold on
    title(num2str(i))
    hold off
end
sgtitle('Scabrous Tissues')


%%% Fix the legends 
%%% Fix the cluster size variance defn check line 28 of bristol code.
%%% Get all the final plots

%%% code to plot a few clusters %%%
% figure
% %set(0,'defaultaxesfontsize',15); 
% %Cluster plot for DCR2
% for i = 1:lenDcr2
%     centers_struct = celldata{i,2}; %Pull out the excel file
%     centers = centers_struct(:,2:3); % pull out X and Y column
%     subplot(6,6,i)  % Plot images on a 6 by 6 grid
% 
%     [silh, epss, minpts] = best_pair(centers);
%     idx11 = dbscan(centers, epss, minpts);
% 
%     gscatter(centers(:,1), centers(:,2),idx11,'rgbm','.',8); 
%     %legend('Location','northeastoutside')
%     legend('off')
%     hold on
%     title(num2str(i))
%     hold off
% end
% sgtitle('Dcr2 Tissues')



